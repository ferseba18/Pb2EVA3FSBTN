package ar.edu.unlam.pb220202c.eva03;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.HashSet;

import org.junit.Test;

public class TestAutoPista {
	@Test
	public void queSePuedaRegistrarTelepase () {
		//String patente, Integer velocidadActual, Integer limiteVelocidad,Boolean Infraccionado
		Vehiculo V1= new Vehiculo("DDD312", 80, 80, false);
		
		assertEquals(V1.registrarTelepase(),true);
		
	}

	public void queAlSalirDelAutopistaNoestaEncirculacionLanceUnaExcepcion()  {
		Vehiculo V1= new Vehiculo("DDD332", 80, 80, false);
		Vehiculo V2= new Vehiculo("DCD352", 60, 80, false);
		Vehiculo V3= new Vehiculo("DAD312", 50, 80, false);
		
		HashMap<Integer, Vehiculo> T1= new HashMap();
		T1.put(123, V1);
		T1.put(1234, V2);
		T1.put(1235, V3);
		HashSet <Vehiculo> VC1=new HashSet();
		VC1.add(V1);
		VC1.add(V2);
		VC1.add(V3);
		Autopista A1 = new Autopista(T1,VC1);
		try {
			A1.salirAutpista(V1);
		} catch (VehiculoNotFounException e) {
			e.printStackTrace("");
		}
		
	}
	
	public void queVerifiqueQueSeObtengaUnaListaDeAutosInsfractoresOrdenadaPorPatente(){
		
	}

	public void generetestAEleccion1() {
		
	}
	
	public void generetestAEleccion2() {
		
	}
	

}
