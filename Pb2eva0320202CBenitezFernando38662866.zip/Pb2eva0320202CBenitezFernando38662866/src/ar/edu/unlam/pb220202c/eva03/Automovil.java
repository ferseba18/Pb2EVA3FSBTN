package ar.edu.unlam.pb220202c.eva03;

public class Automovil extends Vehiculo{
	public Automovil(String patente, Integer velocidadActual, Integer limiteVelocidad, Boolean Infraccionado) {
		super(patente, velocidadActual, limiteVelocidad, Infraccionado);
	}
	private int limiteVelocidad;
	//Si es necesario Utilice herencia o implemente de Interfaces
//	Se debe crear contructeres getters y Setters y loos que crean convenientes
	@Override
	public void setLimiteVelocidad(Integer limiteVelocidad) {
			this.limiteVelocidad = 130;
		}
//el Limite de velociadad para autos es de 130km
//en caso que supere dicho limite el este sera multado

}
