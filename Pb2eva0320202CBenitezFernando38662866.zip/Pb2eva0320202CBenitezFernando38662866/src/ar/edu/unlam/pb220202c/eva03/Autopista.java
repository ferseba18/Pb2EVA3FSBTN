package ar.edu.unlam.pb220202c.eva03;

import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

import javax.print.attribute.standard.Copies;

public class Autopista implements Imultable {
	//Si es necesario Utilice herencia o implemente de Interfaces
		//Se debe crear contructeres getters y Setters y los atributos o metodos que crean convenientes
		private HashMap <Integer,Vehiculo> telapase;
		private HashSet <Vehiculo> vehiculosEnCirculacion;
		public Autopista(HashMap<Integer, Vehiculo> telapase, HashSet<Vehiculo> vehiculosEnCirculacion) {
			this.telapase = telapase;
			this.vehiculosEnCirculacion = vehiculosEnCirculacion;
		}
		
		public HashMap<Integer, Vehiculo> getTelapase() {
			return telapase;
		}
		public void setTelapase(HashMap<Integer, Vehiculo> telapase) {
			this.telapase = telapase;
		}
		public HashSet<Vehiculo> getVehiculosEnCirculacion() {
			return vehiculosEnCirculacion;
		}
		public void setVehiculosEnCirculacion(HashSet<Vehiculo> vehiculosEnCirculacion) {
			this.vehiculosEnCirculacion = vehiculosEnCirculacion;
		}
		
		public Boolean registrarTelepase (Integer numeroTelpase, Vehiculo vehiculo) {
			this.telapase.put(numeroTelpase,vehiculo);
			return true;
			
		}
		public Boolean ingresarAutopista (Integer numeroTelepase) throws VehiculoNotFounException{
			//si el telepase no esta registrado lanza una Exceptios del tipo VehiculoNotFounException
			   // y no permite ingresar al autopista	
			Boolean ingresado = false;
			if(this.telapase.get(numeroTelepase).getClass().equals(Vehiculo.class)) {
				ingresado=true;
			}
			else {
				throw new VehiculoNotFounException("No se encontro el vehiculo");
			}
			return ingresado;
		}
		
		public void salirAutpista (Vehiculo vehiculo) throws VehiculoNotFounException{
			//lanza Una exception VehiculoNotFounException si no esta en circulacion
			if(this.getVehiculosEnCirculacion().contains(vehiculo)){
				vehiculosEnCirculacion.remove(vehiculo);
			}
			else
			{
				throw new VehiculoNotFounException("No se encontro el vehiculo");
			}
		}
		
		public TreeSet<Vehiculo> obtenerVehiculosConExcesosDeVelocidadOrdenadosPorPatente(){
			TreeSet<Vehiculo> VehiculosExcedidos = new TreeSet<>();
		return null;
	    }

		public Integer cantidadDeVehiculosENCirculacion() {
			return vehiculosEnCirculacion.size();
	}
		@Override
		public Boolean enInfraccion(Vehiculo Vehiculo) {
			
			if(Vehiculo.getVelocidadActual() >= Vehiculo.getLimiteVelocidad()) {
				Vehiculo.setInfraccionado(true);
		}
			return Vehiculo.getInfraccionado();
		}
}
