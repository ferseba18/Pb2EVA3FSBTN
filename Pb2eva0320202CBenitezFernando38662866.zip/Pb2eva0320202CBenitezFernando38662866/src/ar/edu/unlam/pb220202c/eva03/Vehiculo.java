package ar.edu.unlam.pb220202c.eva03;

public class Vehiculo {

	//Se debe crear contructeres getters y Setters y loos que crean convenientes
	private String Patente;

	private Integer VelocidadActual;
	private Integer limiteVelocidad;
	private Boolean Infraccionado;
	public Vehiculo(String patente, Integer velocidadActual, Integer limiteVelocidad,Boolean Infraccionado) {
		super();
		this.Patente = patente;
		this.VelocidadActual = velocidadActual;
		this.limiteVelocidad = limiteVelocidad;
		this.Infraccionado=Infraccionado;
	}
	
	private String getPatente() {
		return Patente;
	}


	public void setPatente(String patente) {
		this.Patente = patente;
	}


	public Integer getVelocidadActual() {
		return this.VelocidadActual;
	}


	public void setVelocidadActual(Integer velocidadActual) {
		this.VelocidadActual = velocidadActual;
	}
	public Boolean getInfraccionado() {
		return Infraccionado;
	}

	public void setInfraccionado(Boolean infraccionado) {
		this.Infraccionado = infraccionado;
	}


	public Integer getLimiteVelocidad() {
		return limiteVelocidad;
	}


	public void setLimiteVelocidad(Integer limiteVelocidad) {
		this.limiteVelocidad = limiteVelocidad;
	}

	public void incrmentarVelocidad(Integer Velocidad) {
		this.VelocidadActual=this.VelocidadActual+Velocidad;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Infraccionado == null) ? 0 : Infraccionado.hashCode());
		result = prime * result + ((Patente == null) ? 0 : Patente.hashCode());
		result = prime * result + ((VelocidadActual == null) ? 0 : VelocidadActual.hashCode());
		result = prime * result + ((limiteVelocidad == null) ? 0 : limiteVelocidad.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehiculo other = (Vehiculo) obj;
		if (Infraccionado == null) {
			if (other.Infraccionado != null)
				return false;
		} else if (!Infraccionado.equals(other.Infraccionado))
			return false;
		if (Patente == null) {
			if (other.Patente != null)
				return false;
		} else if (!Patente.equals(other.Patente))
			return false;
		if (VelocidadActual == null) {
			if (other.VelocidadActual != null)
				return false;
		} else if (!VelocidadActual.equals(other.VelocidadActual))
			return false;
		if (limiteVelocidad == null) {
			if (other.limiteVelocidad != null)
				return false;
		} else if (!limiteVelocidad.equals(other.limiteVelocidad))
			return false;
		return true;
	}
	
}
