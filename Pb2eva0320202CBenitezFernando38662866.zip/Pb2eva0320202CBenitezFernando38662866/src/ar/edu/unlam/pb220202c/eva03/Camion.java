package ar.edu.unlam.pb220202c.eva03;

public class Camion extends Vehiculo {
	
	private Integer cantidadDeEjes;
	private int limiteVelocidad;
	public Camion(String patente, Integer velocidadActual, Integer limiteVelocidad, Boolean Infraccionado,
			Integer cantidadDeEjes) {
		super(patente, velocidadActual, limiteVelocidad, Infraccionado);
		this.cantidadDeEjes = cantidadDeEjes;
	}

	//Si es necesario Utilice herencia o implemente de Interfaces
		//Se debe crear contructeres getters y Setters y los que crean conveniente
		//el Limite de velociadad para autos es de 80km
		//en caso que supere dicho limite el este sera multado
@Override
public void setLimiteVelocidad(Integer limiteVelocidad) {
		this.limiteVelocidad = 80;
	}

		public Integer getCantidadDeEjes() {
			return cantidadDeEjes;
		}

		public void setCantidadDeEjes(Integer cantidadDeEjes) {
			this.cantidadDeEjes = cantidadDeEjes;
		}

		
}
